# SudokuSolver
It an interesting game consisting of 2d matrix(9*9) . The game having reset for reseting the number and start new !
"Exit" button for exiting the game.
"Solution" button for see the solution .
"checkMoves" for checking your move .
![2023-06-21 (1)c](https://github.com/VivekBarthwal/SudokuSolver/assets/137098984/cba8b752-f637-4621-bdbb-f28f35242e88)
![2023-06-21 (2)cc](https://github.com/VivekBarthwal/SudokuSolver/assets/137098984/222f1efa-700b-4333-a42b-42eeae3d1f1c)
![2023-06-21 (3)](https://github.com/VivekBarthwal/SudokuSolver/assets/137098984/d46c9857-e6ea-4c74-aeba-1abe9131b209)
![2023-06-21 (4)](https://github.com/VivekBarthwal/SudokuSolver/assets/137098984/28679f0c-3e9c-404a-aea0-c27cf2ecc200)
![2023-06-21ccc](https://github.com/VivekBarthwal/SudokuSolver/assets/137098984/fc0d1a45-195d-49c4-bec3-053815175426)
